
public class    最大公约数与和{
    public static void main(String[] args) {

        System.out.println("hell");
    }
}

